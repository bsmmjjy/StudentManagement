package com.cqupt.stu.schoolmanagement.service;

import com.cqupt.stu.schoolmanagement.entity.StudentEntity;
import com.cqupt.stu.schoolmanagement.repository.StudentRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Optional;

import static org.springframework.http.HttpStatus.NOT_FOUND;

@Service
public class StudentServiceImpl implements StudentService {

    private static final Logger logger = LoggerFactory.getLogger(StudentServiceImpl.class);

    private final StudentRepository studentRepository;

    @Autowired
    public StudentServiceImpl(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }

    @Override
    public List<StudentEntity> getAllStudents() {
        logger.info("Fetching all students.");
        List<StudentEntity> students = studentRepository.findAll();
        logger.info("Successfully fetched {} students.", students.size());
        return students;
    }

    @Override
    public StudentEntity getStudentById(Long studentId) {
        logger.info("Fetching student with ID: {}", studentId);
        Optional<StudentEntity> studentOptional = studentRepository.findById(studentId);
        if (studentOptional.isEmpty()) {
            logger.warn("Student with ID: {} not found.", studentId);
            throw new ResponseStatusException(NOT_FOUND, "Student with ID " + studentId + " not found");
        }
        logger.info("Successfully fetched student with ID: {}.", studentId);
        return studentOptional.get();
    }

    @Override
    @Transactional
    public StudentEntity addStudent(StudentEntity studentEntity) {
        logger.info("Adding a new student: {}", studentEntity.getStudentName());
        validateStudent(studentEntity);
        StudentEntity savedStudent = studentRepository.save(studentEntity);
        logger.info("Successfully added student with ID: {}.", savedStudent.getStudentId());
        return savedStudent;
    }

    @Override
    @Transactional
    public StudentEntity updateStudent(Long studentId, StudentEntity studentEntity) {
        logger.info("Updating student with ID: {}", studentId);
        StudentEntity existingStudent = studentRepository.findById(studentId)
                .orElseThrow(() -> {
                    logger.warn("Student with ID: {} not found for update.", studentId);
                    return new ResponseStatusException(NOT_FOUND, "Student with ID " + studentId + " not found for update");
                });
        updateStudentProperties(existingStudent, studentEntity);
        validateStudent(existingStudent);
        StudentEntity updatedStudent = studentRepository.save(existingStudent);
        logger.info("Successfully updated student with ID: {}.", updatedStudent.getStudentId());
        return updatedStudent;
    }

    @Override
    @Transactional
    public void deleteStudent(Long studentId) {
        logger.info("Deleting student with ID: {}", studentId);
        if (!studentRepository.existsById(studentId)) {
            logger.warn("Student with ID: {} not found for deletion.", studentId);
            throw new ResponseStatusException(NOT_FOUND, "Student with ID " + studentId + " not found for deletion");
        }
        studentRepository.deleteById(studentId);
        logger.info("Successfully deleted student with ID: {}.", studentId);
    }

    @Override
    @Transactional
    public void handleViolation(Long studentId) {
        logger.info("Handling violation for student with ID: {}", studentId);
        StudentEntity student = studentRepository.findById(studentId)
                .orElseThrow(() -> {
                    logger.warn("Student with ID: {} not found for violation handling.", studentId);
                    return new ResponseStatusException(NOT_FOUND, "Student with ID " + studentId + " not found for violation handling");
                });
        student.setViolationCount(student.getViolationCount() + 1);
        studentRepository.save(student);
        logger.info("Successfully updated violation count for student with ID: {}.", studentId);
    }

    /**
     * 验证学生信息的有效性
     * @param studentEntity 学生实体
     * @throws IllegalArgumentException 如果学生名称为空或null
     */
    private void validateStudent(StudentEntity studentEntity) {
        if (studentEntity.getStudentName() == null || studentEntity.getStudentName().isEmpty()) {
            throw new IllegalArgumentException("Student name cannot be null or empty.");
        }
        // 可以添加更多验证逻辑，如教育水平、违纪次数等
    }

    /**
     * 更新学生属性
     * @param existingStudent 已存在的学生实体
     * @param studentEntity 新的学生实体信息
     */
    private void updateStudentProperties(StudentEntity existingStudent, StudentEntity studentEntity) {
        if (studentEntity.getStudentName() != null) {
            existingStudent.setStudentName(studentEntity.getStudentName());
        }
        if (studentEntity.getEducationLevel() != null) {
            existingStudent.setEducationLevel(studentEntity.getEducationLevel());
        }
        if (studentEntity.getViolationCount() >= 0) {
            existingStudent.setViolationCount(studentEntity.getViolationCount());
        }
        // 可以添加更多属性更新逻辑
    }
}