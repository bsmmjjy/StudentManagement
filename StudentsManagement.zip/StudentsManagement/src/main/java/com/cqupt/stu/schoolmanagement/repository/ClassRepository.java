package com.cqupt.stu.schoolmanagement.repository;

import com.cqupt.stu.schoolmanagement.entity.ClassEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClassRepository extends JpaRepository<ClassEntity, Long> {
}
