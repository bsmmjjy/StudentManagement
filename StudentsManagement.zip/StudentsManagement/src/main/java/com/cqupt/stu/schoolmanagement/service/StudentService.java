package com.cqupt.stu.schoolmanagement.service;
import com.cqupt.stu.schoolmanagement.entity.StudentEntity;
import java.util.List;

public interface StudentService {
    List<StudentEntity> getAllStudents();
    StudentEntity getStudentById(Long studentId);
    StudentEntity addStudent(StudentEntity studentEntity);
    StudentEntity updateStudent(Long studentId, StudentEntity studentEntity);
    void deleteStudent(Long studentId);
    void handleViolation(Long studentId); // 违纪处理
}

