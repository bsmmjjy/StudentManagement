package com.cqupt.stu.schoolmanagement.repository;

import com.cqupt.stu.schoolmanagement.entity.StudentEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentRepository extends JpaRepository<StudentEntity, Long> {
}
