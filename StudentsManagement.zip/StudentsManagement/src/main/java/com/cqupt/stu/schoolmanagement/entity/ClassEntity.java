package com.cqupt.stu.schoolmanagement.entity;

import jakarta.persistence.*;
import java.util.List;

@Entity
public class ClassEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long classId;

    private String className;

    @OneToMany(mappedBy = "classEntity", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<StudentEntity> students;

    // Getters and Setters
    public Long getClassId() {
        return classId;
    }

    public void setClassId(Long classId) {
        this.classId = classId;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public List<StudentEntity> getStudents() {
        return students;
    }

    public void setStudents(List<StudentEntity> students) {
        this.students = students;
    }
}
/*
测试指南：
1. 运行StudentsManagementApplication类，启动Spring Boot应用程序。
2. 使用Postman或其他HTTP客户端发送HTTP请求到应用程序的API端点。
3.测试实例：
  - 获取所有班级信息：
        - 请求方法：GET
        - 请求 URL：http://localhost:8080/classes
         - 根据 ID 获取单个班级信息：
        - 请求方法：GET
        - 请求 URL：http://localhost:8080/classes/{classId} （将 {classId} 替换为实际的班级 ID，如 1）

   - 添加新班级信息：
        - 请求方法：POST
        - 请求 URL：http://localhost:8080/classes
        - 请求体：
        {
            "className": "新班级名称"
        }
   - 更新班级信息：
        - 请求方法：PUT
        - 请求 URL：http://localhost:8080/classes/{classId} （将 {classId} 替换为实际的班级 ID，如 1）
        - 请求体：
        {
            "className": "更新后的班级名称"
        }

    - 删除班级信息：
        - 请求方法：DELETE
        - 请求 URL：http://localhost:8080/classes/{classId} （将 {classId} 替换为实际的班级 ID，如 1）

*/
