package com.cqupt.stu.schoolmanagement.service;

import com.cqupt.stu.schoolmanagement.entity.ClassEntity;
import java.util.List;

public interface ClassService {
    List<ClassEntity> getAllClasses();
    ClassEntity getClassById(Long classId);
    ClassEntity addClass(ClassEntity classEntity);
    ClassEntity updateClass(Long classId, ClassEntity classEntity);
    void deleteClass(Long classId);
}
