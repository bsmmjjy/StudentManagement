package com.cqupt.stu.schoolmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentsManagementApplication {

    public static void main(String[] args) {
        SpringApplication.run(StudentsManagementApplication.class, args);
    }

}
