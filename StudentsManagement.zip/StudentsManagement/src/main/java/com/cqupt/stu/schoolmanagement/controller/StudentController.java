package com.cqupt.stu.schoolmanagement.controller;

import com.cqupt.stu.schoolmanagement.entity.StudentEntity;
import com.cqupt.stu.schoolmanagement.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/students")
public class StudentController {

    @Autowired
    private StudentService studentService;

    @GetMapping
    public List<StudentEntity> getAllStudents() {
        return studentService.getAllStudents();
    }

    @GetMapping("/{studentId}")
    public StudentEntity getStudentById(@PathVariable Long studentId) {
        return studentService.getStudentById(studentId);
    }

    @PostMapping
    public StudentEntity addStudent(@RequestBody StudentEntity studentEntity) {
        return studentService.addStudent(studentEntity);
    }

    @PutMapping("/{studentId}")
    public StudentEntity updateStudent(@PathVariable Long studentId, @RequestBody StudentEntity studentEntity) {
        return studentService.updateStudent(studentId, studentEntity);
    }

    @DeleteMapping("/{studentId}")
    public void deleteStudent(@PathVariable Long studentId) {
        studentService.deleteStudent(studentId);
    }

    @PostMapping("/{studentId}/violation")
    public void handleViolation(@PathVariable Long studentId) {
        studentService.handleViolation(studentId);
    }
}
