package com.cqupt.stu.schoolmanagement.controller;

import com.cqupt.stu.schoolmanagement.entity.ClassEntity;
import com.cqupt.stu.schoolmanagement.service.ClassService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/classes")
public class ClassController {

    @Autowired
    private ClassService classService;

    @GetMapping
    public List<ClassEntity> getAllClasses() {
        return classService.getAllClasses();
    }

    @GetMapping("/{classId}")
    public ClassEntity getClassById(@PathVariable Long classId) {
        return classService.getClassById(classId);
    }

    @PostMapping
    public ClassEntity addClass(@RequestBody ClassEntity classEntity) {
        return classService.addClass(classEntity);
    }

    @PutMapping("/{classId}")
    public ClassEntity updateClass(@PathVariable Long classId, @RequestBody ClassEntity classEntity) {
        return classService.updateClass(classId, classEntity);
    }

    @DeleteMapping("/{classId}")
    public void deleteClass(@PathVariable Long classId) {
        classService.deleteClass(classId);
    }
}
