package com.cqupt.stu.schoolmanagement.service;

import com.cqupt.stu.schoolmanagement.entity.ClassEntity;
import com.cqupt.stu.schoolmanagement.repository.ClassRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Optional;

import static org.springframework.http.HttpStatus.NOT_FOUND;

@Service
public class ClassServiceImpl implements ClassService {

    private static final Logger logger = LoggerFactory.getLogger(ClassServiceImpl.class);

    private final ClassRepository classRepository;

    @Autowired
    public ClassServiceImpl(ClassRepository classRepository) {
        this.classRepository = classRepository;
    }

    @Override
    public List<ClassEntity> getAllClasses() {
        logger.info("Fetching all classes.");
        List<ClassEntity> classes = classRepository.findAll();
        for (ClassEntity classEntity : classes) {
            System.out.println(classEntity);
        }
        logger.info("Successfully fetched {} classes.", classes.size());
        return classes;
    }

    @Override
    public ClassEntity getClassById(Long classId) {
        logger.info("Fetching class with ID: {}", classId);
        Optional<ClassEntity> classEntityOptional = classRepository.findById(classId);
        if (classEntityOptional.isEmpty()) {
            logger.warn("Class with ID: {} not found.", classId);
            throw new ResponseStatusException(NOT_FOUND, "Class with ID " + classId + " not found");
        }
        logger.info("Successfully fetched class with ID: {}.", classId);
        return classEntityOptional.get();
    }

    @Override
    @Transactional
    public ClassEntity addClass(ClassEntity classEntity) {
        logger.info("Adding a new class: {}", classEntity.getClassName());
        validateClass(classEntity);
        ClassEntity savedClass = classRepository.save(classEntity);
        logger.info("Successfully added class with ID: {}.", savedClass.getClassId());
        return savedClass;
    }

    @Override
    @Transactional
    public ClassEntity updateClass(Long classId, ClassEntity classEntity) {
        logger.info("Updating class with ID: {}", classId);
        ClassEntity existingClass = classRepository.findById(classId)
                .orElseThrow(() -> {
                    logger.warn("Class with ID: {} not found for update.", classId);
                    return new ResponseStatusException(NOT_FOUND, "Class with ID " + classId + " not found for update");
                });
        updateClassProperties(existingClass, classEntity);
        validateClass(existingClass);
        ClassEntity updatedClass = classRepository.save(existingClass);
        logger.info("Successfully updated class with ID: {}.", updatedClass.getClassId());
        return updatedClass;
    }

    @Override
    @Transactional
    public void deleteClass(Long classId) {
        logger.info("Deleting class with ID: {}", classId);
        if (!classRepository.existsById(classId)) {
            logger.warn("Class with ID: {} not found for deletion.", classId);
            throw new ResponseStatusException(NOT_FOUND, "Class with ID " + classId + " not found for deletion");
        }
        classRepository.deleteById(classId);
        logger.info("Successfully deleted class with ID: {}.", classId);
    }

    /**
     * 验证班级信息的有效性
     * @param classEntity 班级实体
     * @throws IllegalArgumentException 如果班级名称为空或null
     */
    private void validateClass(ClassEntity classEntity) {
        if (classEntity.getClassName() == null || classEntity.getClassName().isEmpty()) {
            throw new IllegalArgumentException("Class name cannot be null or empty.");
        }
        // 可以添加更多验证逻辑
    }

    /**
     * 更新班级属性
     * @param existingClass 已存在的班级实体
     * @param classEntity 新的班级实体信息
     */
    private void updateClassProperties(ClassEntity existingClass, ClassEntity classEntity) {
        if (classEntity.getClassName() != null) {
            existingClass.setClassName(classEntity.getClassName());
        }
        // 可以添加更多属性更新逻辑
    }
}