#include<iostream>
#include<string.h>
using namespace std;

class Desk{
private:
	double length;
	double weight;
	double high;
	double width;
public:
	Desk(double lengthV, double weightV, double highV, double widthV){
		length = lengthV;
		weight = weightV;
		high = highV;
		width = widthV;
	}
	void print(){
		cout << "�������ӣ��ҵ���Χ�ǣ�" << length << ","
			<< weight << ","
			<< high << ","
			<< width << endl;
	}
};
Desk d1(100, 75.5, 120.0, 70);
void main(){
	d1.print();
}

















